function isValidUrl(url) {
    if (url === '') {
        return true;
    }
    const urlRegex = /^https?:\/\/([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}([\/\?].*)?$/i;
    return urlRegex.test(url);
}

function showAlert(message, success=true) {
    var alertDiv = $('#alert');
    alertDiv.text(message);
    alertDiv.removeClass('d-none');
    if (success) {
        alertDiv.removeClass('alert-danger').addClass('alert-primary');
    } else {
        alertDiv.removeClass('alert-primary').addClass('alert-danger');
    }
}

$('#on-btn').click(function() {
    $('#confirmOnModal').modal('show');
});

$('#confirmOnAction').click(function() {
    var textareaContent = $('#textarea-content').val();
    $.post('/cusHtml/', { state: 'on', content: textareaContent }, function(data, status){
        if(status === 'success'){
            location.reload();  // Add this line to reload the page
        } else {
            showAlert('开启失败，请稍后重试。', false);
        }
    });
    $('#confirmOnModal').modal('hide');
});

$('#off-btn').click(function() {
    $('#confirmOffModal').modal('show');
});

$('#confirmOffAction').click(function() {
    var textareaContent = $('#textarea-content').val();
    $.post('/cusHtml/', { state: 'off', content: textareaContent }, function(data, status){
        if(status === 'success'){
            location.reload();  // Add this line to reload the page
        } else {
            showAlert('关闭失败，请稍后重试。', false);
        }
    });
    $('#confirmOffModal').modal('hide');
});

$(document).ready(function() {
// Get the initial state and content from the server
$.get('/cusHtml/', function(data, status){
if(status === 'success'){
    var state = data.state;
    var content = data.content;

    // Update the state and content on the page
    if (state === 'on') {
        $('#status-icon').addClass('fa-check-circle').removeClass('fa-times-circle').css('color', 'green');
        $('#status-text').text('自定义HTML功能已开启').css('color', 'green');
    } else {
        $('#status-icon').addClass('fa-times-circle').removeClass('fa-check-circle').css('color', 'red');
        $('#status-text').text('自定义HTML功能未开启').css('color', 'red');
    }
    $('#status-text').css('opacity', '0');
    setTimeout(function() {
        $('#status-text').css('opacity', '1');
    }, 50);
    $('#textarea-content').val(content);
}
});
});

function displayMessage(id, message, type) {
    var alertType = type === 'success' ? 'alert-success' : 'alert-danger';
    var html = '<div class="alert ' + alertType + ' alert-dismissible fade show" role="alert">' + message +
               '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';

    $('#' + id).html(html);

    // Remove the message after 5 seconds
    setTimeout(function() {
        $('#' + id).empty();
    }, 2000);
}


function sendPortsToServer(id) {
    var portsInput = $('#' + id).val();
    var ports = portsInput === '' ? [] : portsInput.split(',').map(Number).filter(function(port) {
        return port >= 1 && port <= 65535;
    });

    // Only mark as invalid if there's input but none of the ports are valid
    if (portsInput !== '' && ports.length === 0) {
        $('#' + id).addClass('is-invalid');
        return;
    }

    // Remove invalid class regardless of whether input was valid
    $('#' + id).removeClass('is-invalid');

    // Convert ports to strings
    ports = ports.map(function(port) {
        return port.toString();
    });

    $('#' + id + '-result').html('<div class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>');

    $.ajax({
        url: '/ports/',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ type: id.split('-')[0], ports: ports }),
        success: function(data){
            var resultId = id.split('-')[0] + '-result';
            $('#' + resultId).empty();
            if(data.status == 'success'){
                displayMessage(resultId, '保存成功！', 'success');
            } else {
                displayMessage(resultId, '保存失败，请稍后重试。', 'danger');
            }
        }
    });
}

$(document).ready(function() {
    $.get('/ports/', function(data) {
        if (data.http_ports && data.http_ports.length > 0) {
            $('#http-ports').val(data.http_ports.join(','));
        }
        if (data.https_ports && data.https_ports.length > 0) {
            $('#https-ports').val(data.https_ports.join(','));
        }
    });

    $('#save-http').click(function() {
        sendPortsToServer('http-ports');
    });

    $('#save-https').click(function() {
        sendPortsToServer('https-ports');
    });

});



$('#default-jump-url').on('input', function() {
    var defaultUrl = $(this).val();
    if (!isValidUrl(defaultUrl)) {
        $(this).addClass('is-invalid');
        $('#default-url-result').html('<div class="invalid-feedback">请输入一个有效的URL。</div>');
    } else {
        $(this).removeClass('is-invalid');
        $('#default-url-result').empty();
    }
});

$('#save-default-url').click(function() {
    var defaultUrl = $('#default-jump-url').val();
    if (!isValidUrl(defaultUrl)) {
        return;
    }

    $(this).prop('disabled', true);
    $('#default-url-result').html('<div class="spinner-border" role="status"><span class="sr-only">Loading...</span></div>');

    $.ajax({
        url: '/default_jump_url/',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ default_jump_url: defaultUrl }),
        success: function(data){
            $('#save-default-url').prop('disabled', false);
            if(data.status == 'success'){
                // 发起 GET 请求获取最新的默认跳转地址
                $.ajax({
                    url: '/default_jump_url/',
                    type: 'GET',
                    success: function(data) {
                        $('#default-jump-url').val(data.default_jump_url);
                        displayMessage('default-url-result', '保存成功！', 'success');
                    }
                });
            } else {
                displayMessage('default-url-result', '保存失败，请稍后重试。', 'danger');
            }
        }
    });
});


$(document).ready(function() {
    $.ajax({
        url: '/default_jump_url/',
        type: 'GET',
        success: function(data) {
            $('#default-jump-url').val(data.default_jump_url);
        }
    });
});

